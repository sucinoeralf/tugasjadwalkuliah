package com.example.jadwalkuliah;

import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;


//hello
public class JumatActivity extends AppCompatActivity {

    String[] daftar;
    ListView ListView01;
    Menu menu;
    DataHelper dbcenter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_jumat);
        dbcenter = new DataHelper(this);
        JadwalJumat();
    }

    private void JadwalJumat() {
        SQLiteDatabase db = dbcenter.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM jadwal where hari = 'Jumat'", null);
        daftar = new String[cursor.getCount()];
        cursor.moveToFirst();
        for (int cc = 0; cc < cursor.getCount(); cc++) {
            cursor.moveToPosition(cc);
            daftar[cc] = cursor.getString(1).toString();
        }
        ListView01 = (ListView) findViewById(R.id.listView1);
        ListView01.setAdapter(new ArrayAdapter(this, android.R.layout.simple_list_item_1, daftar));
        ListView01.setSelected(true);
        ListView01.setOnItemClickListener((new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                final String selection = daftar[position]; //.getItemAtPosition(arg2).toString();
                final CharSequence[] dialogitem = {"Lihat Jadwal","Update Jadwal", "Hapus Jadwal"};
                AlertDialog.Builder builder = new AlertDialog.Builder(JumatActivity.this);
                builder.setTitle("Pilihan");
                builder.setItems(dialogitem, new DialogInterface.OnClickListener() {
                    public void onClick(DialogInterface dialog, int item) {
                        switch (item) {
                            case 0 :
                                Intent i = new Intent(getApplicationContext(), LihatJadwal.class);
                                i.putExtra("nama_makul", selection);
                                startActivity(i);
                                break;
                            case 1:
                                Intent in = new Intent(getApplicationContext(), EditJadwal.class);
                                in.putExtra("nama_makul", selection);
                                startActivity(in);
                                break;
                            case 2:
                                SQLiteDatabase db = dbcenter.getWritableDatabase();
                                db.execSQL("delete from jadwal where nama_makul = '" + selection + "'");
                                JadwalJumat();
                                break;
                        }
                    }
                });
                builder.create().show();
            }
        }));
        ((ArrayAdapter) ListView01.getAdapter()).notifyDataSetInvalidated();
    }

    public static class EditJadwal extends AppCompatActivity {

        protected Cursor cursor;
        DataHelper dbHelper;
        Button ton1, ton2;
        EditText text1, text2, text3, text4, text5, text6;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_edit_jadwal);

            dbHelper = new DataHelper(this);
            text1 = (EditText) findViewById(R.id.editText1);
            text2 = (EditText) findViewById(R.id.editText2);
            text3 = (EditText) findViewById(R.id.editText3);
            text4 = (EditText) findViewById(R.id.editText4);
            text5 = (EditText) findViewById(R.id.editText5);
            text6 = (EditText) findViewById(R.id.editText6);
            SQLiteDatabase db = dbHelper.getReadableDatabase();
            cursor = db.rawQuery("SELECT * FROM jadwal WHERE nama_makul = '" +
                    getIntent().getStringExtra("nama_makul") + "'",null);
            cursor.moveToFirst();

            if (cursor.getCount()>0)
            {
                cursor.moveToPosition(0);
                text1.setText(cursor.getString(0).toString());
                text2.setText(cursor.getString(1).toString());
                text3.setText(cursor.getString(2).toString());
                text4.setText(cursor.getString(3).toString());
                text5.setText(cursor.getString(4).toString());
                text6.setText(cursor.getString(5).toString());
            }

            ton1 = (Button) findViewById(R.id.button1);
            ton2 = (Button) findViewById(R.id.button2);

            ton1.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View arg0) {

                    SQLiteDatabase db = dbHelper.getWritableDatabase();
                    db.execSQL("update jadwal set nama_makul='"+
                            text2.getText().toString() +"', ruang='" +
                            text3.getText().toString() +"', jam='"+
                            text4.getText().toString() +"', hari='" +
                            text5.getText().toString() +"', dosen='"+
                            text6.getText().toString() +"' where no='" +
                            text1.getText().toString()+"'");
                    Toast.makeText(getApplicationContext(), "Berhasil", Toast.LENGTH_LONG).show();
                    finish();
                    Intent iselasa = getIntent();
                    iselasa = new Intent(EditJadwal.this, Jadwal.class);
                    startActivity(iselasa);
                }
            });
            ton2.setOnClickListener(new View.OnClickListener() {

                @Override
                public void onClick(View arg0) {
                    finish();
                }
            });
        }
    }
}
